package com.example.trump

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
