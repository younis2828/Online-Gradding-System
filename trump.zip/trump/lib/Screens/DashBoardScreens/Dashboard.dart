import 'package:flutter/material.dart';

import 'ChatScreen/Chat.dart';
import 'Match/MatchScreen.dart';
import 'ProfileScreen/Profile.dart';
import 'ReelsScreen/Reels.dart';

void main() {
  runApp(MaterialApp(
    home: DashboardScreen(),
  ));
}

class DashboardScreen extends StatefulWidget {
  @override
  _DashboardScreenState createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  int _selectedIndex = 0;

  List<Widget> _widgetOptions = [
    HomeScreen(),
    MatchScreen(),
    ReelsScreen(),
    ChatScreen(),
    ProfileScreen(),
  ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.red,
        title: Text('Dashboard'),
        actions: [
          IconButton(
            icon: Icon(Icons.notifications),
            onPressed: () {
              // Handle notifications
            },
          ),
        ],
      ),
      body: _widgetOptions[_selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        items: <BottomNavigationBarItem>[
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
          BottomNavigationBarItem(icon: Icon(Icons.favorite), label: 'Match'),
          BottomNavigationBarItem(icon: Icon(Icons.video_library), label: 'Reels'),
          BottomNavigationBarItem(icon: Icon(Icons.chat), label: 'Chat'),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: 'Profile'),
        ],
        currentIndex: _selectedIndex,
        selectedItemColor: Colors.red,
        unselectedItemColor: Colors.black,
        onTap: _onItemTapped,
      ),
    );
  }
}

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: EdgeInsets.only(top: 15),
            child: Row(
              children: [
                CircleAvatar(
                  backgroundImage: AssetImage('assets/images/homeimage.png'),
                  radius: 30,
                ),
                SizedBox(width: 10),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Good Morning'),
                    Text('Andrew Ainesley',style: TextStyle(fontWeight: FontWeight.bold),),
                  ],
                ),
                Spacer(),
                IconButton(
                  icon: Icon(Icons.notifications),
                  onPressed: ()
                  {
                    // Handle notifications
                  },
                ),
              ],
            ),
          ),
          Container(
              width: 800,
              height: 300,
              child: Image.asset('assets/images/homeimage.png',
              )

          ),
          Padding(
            padding: EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Alfredo, Calzoni'),
                Row(
                  children: [
                    Icon(Icons.location_on),
                    Text('Hamburg, Germany (1.6 Miles)'),
                  ],
                ),
              ],
            ),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              Column(
                children: [
                  Image.asset(
                    'assets/icons/dislike.png',
                    width: 60,
                    height: 60,
                  ),
                  Text("Dislike")
                ],
              ),
             
              Column(
                children: [
                  Image.asset(
                    'assets/icons/icon2.png',
                    width: 60,
                    height: 60,
                  ),
                  Text("Super Like")
                ],
              ),
              Column(
                children: [
                  Image.asset(
                    'assets/icons/like.png',
                    width: 60,
                    height: 60,
                  ),
                  Text("Like")
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }
}
