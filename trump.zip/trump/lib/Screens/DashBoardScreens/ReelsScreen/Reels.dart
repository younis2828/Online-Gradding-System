import 'package:flutter/material.dart';

class ReelsScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        fit: StackFit.expand,
        children: [
          // Video Widget (replace with your video widget)
          VideoWidget(),

          // Buttons Overlay
          Positioned(
            top: 0,
            bottom: 0,
            right: 0,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                IconButton(
                  onPressed: () {
                    // Handle Like button press
                  },
                  icon: Icon(Icons.favorite, color: Colors.white,size: 30,),
                ),
                IconButton(
                  onPressed: () {
                    // Handle Comment button press
                  },
                  icon: Icon(Icons.comment, color: Colors.white,size: 30,),
                ),
                IconButton(
                  onPressed: () {
                    // Handle Share button press
                  },
                  icon: Icon(Icons.share, color: Colors.white,size: 30,),
                ),
                IconButton(
                  onPressed: () {
                    // Handle Save button press
                  },
                  icon: Icon(Icons.save, color: Colors.white,size: 30,),
                ),
                SizedBox(height: 20),
                FloatingActionButton(
                  onPressed: () {
                    // Handle Add button (Plus sign) press
                  },
                  child: Icon(Icons.add, color: Colors.white),
                  backgroundColor: Colors.red,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class VideoWidget extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // Replace with your video widget implementation
    return Container(
      color: Colors.black, // Placeholder color
      child: Center(
        child: Image.asset("assets/images/homeimage.png")
      ),
    );
  }
}

