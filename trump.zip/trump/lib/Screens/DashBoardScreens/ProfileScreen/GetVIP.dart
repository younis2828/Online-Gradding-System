import 'package:flutter/material.dart';

import 'PaymentMethod.dart';

class GetVIP extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.red, // Red app bar color
        title: Text('Get VIP'),
      ),
      body: Column(
        children: [
          SizedBox(height: 20,),
          Expanded(
            child: GestureDetector(
              onTap: ()
              {
               Navigator.push(context, MaterialPageRoute(builder: (context)=>PaymentMethod()));
              },
              child: Container(
                width: 370,
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.red), // Red outline border
                ),
                padding: EdgeInsets.all(16),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Image.asset('assets/icons/king.png'),
                    SizedBox(height: 10),
                    Text(
                      'Make America Straight Again',
                      style: TextStyle(
                        color: Colors.black,
                        fontWeight: FontWeight.bold,
                        fontSize: 18,
                      ),
                    ),
                    Text(
                      '4.99\$/month',
                      style: TextStyle(
                        color: Colors.red,
                        fontSize: 16,
                      ),
                    ),
                    SizedBox(height: 10),
                    Row(
                      children: [
                        Icon(Icons.check, color: Colors.red),
                        SizedBox(width: 5),
                        Text('Unlimited Likes', style: TextStyle(color: Colors.red)),
                      ],
                    ),
                    Row(
                      children: [
                        Icon(Icons.check, color: Colors.red),
                        SizedBox(width: 5),
                        Text('5 Super Likes a Day', style: TextStyle(color: Colors.red)),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
          SizedBox(height: 16), // Add spacing between the containers
          Expanded(
            child: GestureDetector(
              onTap: () {
                Navigator.push(context, MaterialPageRoute(builder: (context)=>PaymentMethod()));
              },
              child: Container(
                width: 370,
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.red), // Red outline border
                ),
                padding: EdgeInsets.all(16),
                child: Container(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Image.asset('assets/icons/king.png'),
                      SizedBox(height: 10),
                      Text(
                        'Make Dating Great Again',
                        style: TextStyle(
                          color: Colors.black,
                          fontWeight: FontWeight.bold,
                          fontSize: 18,
                        ),
                      ),
                      Text(
                        '8.99\$/month',
                        style: TextStyle(
                          color: Colors.red,
                          fontSize: 16,
                        ),
                      ),
                      SizedBox(height: 10),
                      Row(
                        children: [
                          Icon(Icons.check, color: Colors.red),
                          SizedBox(width: 5),
                          Text('Unlimited Likes', style: TextStyle(color: Colors.red)),
                        ],
                      ),
                      Row(
                        children: [
                          Icon(Icons.check, color: Colors.red),
                          SizedBox(width: 5),
                          Text('10 Super Likes a Day', style: TextStyle(color: Colors.red)),
                        ],
                      ),
                      Row(
                        children: [
                          Icon(Icons.check, color: Colors.red),
                          SizedBox(width: 5),
                          Text('Ping 5 People in a Day', style: TextStyle(color: Colors.red)),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
