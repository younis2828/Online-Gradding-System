import 'package:flutter/material.dart';

import 'EditProfile.dart';

class ReviewPayment extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Review Payment'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(height: 20),
            Container(
              decoration: BoxDecoration(
                border: Border.all(color: Colors.red), // Red outline border
              ),
              padding: EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Center(child: Image.asset('assets/icons/king.png')),
                  SizedBox(height: 10),
                  Center(
                    child: Text(
                      'Make America Straight Again',
                      style: TextStyle(
                        color: Colors.black,
                        fontWeight: FontWeight.bold,
                        fontSize: 18,
                      ),
                    ),
                  ),
                  Center(
                    child: Text(
                      '4.99\$/month',
                      style: TextStyle(
                        color: Colors.red,
                        fontSize: 16,
                      ),
                    ),
                  ),
                  SizedBox(height: 10),
                  Row(
                    children: [
                      Icon(Icons.check, color: Colors.red),
                      SizedBox(width: 5),
                      Text('Unlimited Likes', style: TextStyle(color: Colors.red)),
                    ],
                  ),
                  Row(
                    children: [
                      Icon(Icons.check, color: Colors.red),
                      SizedBox(width: 5),
                      Text('5 Super Likes a Day', style: TextStyle(color: Colors.red)),
                    ],
                  ),
                ],
              ),
            ),
            SizedBox(height: 40),
            Container(
              width: 400,
              height: 200,
              decoration: BoxDecoration(
                border: Border.all(color: Colors.black87), // Light black outline border
              ),
              padding: EdgeInsets.all(16),
              child: Center(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('Amount',style: TextStyle(fontSize: 20),),
                        Text('\$9.99',style: TextStyle(fontSize: 20),),
                      ],
                    ),
                    SizedBox(height: 10),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('Tax',style: TextStyle(fontSize: 20),),
                        Text('\$1.99',style: TextStyle(fontSize: 20),),
                      ],
                    ),
                    SizedBox(height: 10),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('Total Amount',style: TextStyle(fontSize: 20),),
                        Text('\$11.99',style: TextStyle(fontSize: 20),),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            Spacer(),
            SizedBox(
              width: 400,
              height: 60,
              child: ElevatedButton(
                onPressed: () {
                  _showConfirmationPopup(context);
                },
                child: Text('Confirm Payment'),
                style: ElevatedButton.styleFrom(
                  primary: Colors.red, // Red background color
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

void _showConfirmationPopup(BuildContext context) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return AlertDialog(
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              decoration: BoxDecoration(
                color: Colors.red,
                shape: BoxShape.circle,
              ),
              padding: EdgeInsets.all(20),
              child: Image.asset('assets/icons/king.png'),
            ),
            SizedBox(height: 10),
            Text(
              'Thank You',
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 20,
              ),
            ),
            SizedBox(height: 10),
            Text(
              'You have successfully subscribed to MASA for 1 Month. Enjoy the benefits!',
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: ()
              {
                Navigator.of(context).pop(); // Close the popup
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => EditProfile()),
                );
              },
              child: Container(
                  child: Text('Continue')),
              style: ElevatedButton.styleFrom(
                primary: Colors.red, // Red background color
              ),
            ),
          ],
        ),
      );
    },
  );
}

