import 'package:flutter/material.dart';

import 'Profile.dart';

class EditProfile extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Edit Profile'),
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: CircleAvatar(
                radius: 60,
                backgroundImage: AssetImage('assets/images/homeimage.png'),
              ),
            ),
            SizedBox(height: 20),
            TextFieldWithOutline('Thamasben Son'),
            SizedBox(height: 10),
            TextFieldWithOutline('15/04/2003'),
            SizedBox(height: 10),
            GenderSelection(),
            SizedBox(height: 10),
            TextFieldWithOutline('Hamburg, Germany'),
            SizedBox(height: 10),
            TextFieldWithOutline('School of Hard Knock'),
            SizedBox(height: 10),
            TextFieldWithOutline('Computer Science'),
            SizedBox(height: 10),
            PassionSelection(),
            SizedBox(height: 20),
            SizedBox(
              width: 400,
              height: 60,
              child: ElevatedButton(
                onPressed: ()
                {
                  Navigator.push(context, MaterialPageRoute(builder: (context)=>ProfileScreen()));
                },
                child: Text('Save Profile'),
                style: ElevatedButton.styleFrom(
                  primary: Colors.red, // Red background color
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class TextFieldWithOutline extends StatelessWidget {
  final String initialValue;

  TextFieldWithOutline(this.initialValue);

  @override
  Widget build(BuildContext context) {
    return TextFormField(
      initialValue: initialValue,
      decoration: InputDecoration(
        border: OutlineInputBorder(),
      ),
    );
  }
}

class GenderSelection extends StatefulWidget {
  @override
  _GenderSelectionState createState() => _GenderSelectionState();
}

class _GenderSelectionState extends State<GenderSelection> {
  String selectedGender = 'Male';

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Radio(
          value: 'Male',
          groupValue: selectedGender,
          onChanged: (value) {
            setState(() {
              selectedGender = value!;
            });
          },
        ),
        Text('Male'),
        Radio(
          value: 'Female',
          groupValue: selectedGender,
          onChanged: (value) {
            setState(() {
              selectedGender = value!;
            });
          },
        ),
        Text('Female'),
      ],
    );
  }
}

class PassionSelection extends StatelessWidget {
  final List<String> passions = [
    'DIY', 'Hugx Hug', 'Politics', 'Cycling', 'Museum', 'Outdoors', 'Shopping',
    'Picnicking', 'Comedy', 'Brunch', 'Music', 'Netflix', 'Tea X', 'Disney',
    'Dog Lover', 'Craft Beer', 'Swimming', 'Board Games X', 'via Trivia',
    'Volunteering', 'Hiking', 'Environmentalism X', 'Wine', 'Vlogging', 'Yoga X',
    'Cat Lover', 'Working Out', 'Fishing'
  ];

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('Passions'),
        Wrap(
          spacing: 10,
          children: passions
              .map(
                (passion) => Container(
              decoration: BoxDecoration(
                border: Border.all(color: Colors.grey),
                borderRadius: BorderRadius.circular(12),
              ),
              padding: EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              child: Text(passion),
            ),
          )
              .toList(),
        ),
      ],
    );
  }
}

