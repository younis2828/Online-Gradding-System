import 'package:flutter/material.dart';

import 'ConfirmPayment.dart';

class PaymentMethod extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Payment Methods'),
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            PaymentOptionRow('assets/icons/paypal.png', 'Paypal', true),
            PaymentOptionRow('assets/icons/googlepay.png', 'Google Pay', false),
            PaymentOptionRow('assets/icons/bank.png', 'Credit Card/Debit Card', false),
            PaymentOptionRow('assets/icons/bank2.png', 'Bank Transfer', false),
            SizedBox(height: 30),
            Center(
              child: TextButton.icon(
                onPressed: () {
                  // Handle "Add New Card" button press
                },
                icon: Icon(Icons.add, color: Colors.red),
                label: Text('Add New Card', style: TextStyle(color: Colors.red)),
              ),
            ),
            Spacer(),
            ElevatedButton(
              onPressed: ()
              {
                Navigator.push(context, MaterialPageRoute(builder: (context)=>ReviewPayment()));
              },
              child: Container(
                  width: 400,
                  height: 60,
                  color: Colors.red,
                  child: Center(child: Text('Continue'))),
            ),
          ],
        ),
      ),
    );
  }
}

class PaymentOptionRow extends StatelessWidget {
  final String imagePath;
  final String optionText;
  final bool isSelected;

  PaymentOptionRow(this.imagePath, this.optionText, this.isSelected);

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Image.asset(imagePath, width: 70, height: 90),
        SizedBox(width: 30),
        Text(
          optionText,
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        Spacer(),
        if (isSelected) Icon(Icons.check_circle, color: Colors.green),
      ],
    );
  }
}

