import 'package:flutter/material.dart';

class NotificationScreen extends StatefulWidget {
  @override
  _NotificationScreenState createState() => _NotificationScreenState();
}

class _NotificationScreenState extends State<NotificationScreen> {
  bool showMessagePreview = true;
  bool newMessage = true;
  bool newMatch = true;
  bool matchAroundMe = true;
  bool youGotLikes = true;
  bool youGotStar = true;
  bool subscription = true;
  bool sound = true;
  bool vibrate = true;
  bool newUpdate = true;
  bool vipStatus = true;
  bool newServices = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Notification Settings'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16.0),
        children: [
          NotificationOption('Show Message Preview', showMessagePreview, (value) {
            _toggleOption(value, () {
              showMessagePreview = value;
            });
          }),
          NotificationOption('New Message', newMessage, (value) {
            _toggleOption(value, () {
              newMessage = value;
            });
          }),
          NotificationOption('New Match', newMatch, (value) {
            _toggleOption(value, () {
              newMatch = value;
            });
          }),
          NotificationOption('Match Around Me', matchAroundMe, (value) {
            _toggleOption(value, () {
              matchAroundMe = value;
            });
          }),
          NotificationOption('You Got Likes', youGotLikes, (value) {
            _toggleOption(value, () {
              youGotLikes = value;
            });
          }),
          NotificationOption('You Got Star', youGotStar, (value) {
            _toggleOption(value, () {
              youGotStar = value;
            });
          }),
          NotificationOption('Subscription', subscription, (value) {
            _toggleOption(value, () {
              subscription = value;
            });
          }),
          NotificationOption('Sound', sound, (value) {
            _toggleOption(value, () {
              sound = value;
            });
          }),
          NotificationOption('Vibrate', vibrate, (value) {
            _toggleOption(value, () {
              vibrate = value;
            });
          }),
          NotificationOption('New Update', newUpdate, (value) {
            _toggleOption(value, () {
              newUpdate = value;
            });
          }),
          NotificationOption('VIP Status', vipStatus, (value) {
            _toggleOption(value, () {
              vipStatus = value;
            });
          }),
          NotificationOption('New Services', newServices, (value) {
            _toggleOption(value, () {
              newServices = value;
            });
          }),
        ],
      ),
    );
  }

  void _toggleOption(bool value, Function setStateFunction) {
    setState(() {
      setStateFunction();
    });
  }
}

class NotificationOption extends StatelessWidget {
  final String title;
  final bool value;
  final Function(bool) onChanged;

  NotificationOption(this.title, this.value, this.onChanged);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(title),
          Switch(
            value: value,
            onChanged: onChanged,
            activeColor: Colors.red,
          ),
        ],
      ),
    );
  }
}
