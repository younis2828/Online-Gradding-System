import 'package:flutter/material.dart';

class SecurityScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Security Settings'),
        backgroundColor: Colors.red,
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SecurityOption('Remember Me', false),
          SecurityOption('Face ID', false),
          SecurityOption('Biometric ID', false),
          GestureDetector(
            onTap: () {
              // Navigate to Change Pin screen
              // You can use Navigator.push here
            },
            child: SecurityOption('Change Pin', true),
          ),
          GestureDetector(
            onTap: () {
              // Navigate to Change Password screen
              // You can use Navigator.push here
            },
            child: SecurityOption('Change Password', true),
          ),
        ],
      ),
    );
  }
}

class SecurityOption extends StatefulWidget {
  final String title;
  final bool hasArrow;

  SecurityOption(this.title, this.hasArrow);

  @override
  _SecurityOptionState createState() => _SecurityOptionState();
}

class _SecurityOptionState extends State<SecurityOption> {
  bool _value = false;

  @override
  Widget build(BuildContext context) {
    return ListTile(
      onTap: () {
        setState(() {
          _value = !_value;
        });
      },
      title: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(widget.title),
          if (widget.hasArrow) Icon(Icons.arrow_forward_ios),
          Switch(
            value: _value,
            onChanged: (newValue) {
              setState(() {
                _value = newValue;
              });
            },
            activeColor: Colors.red,
          ),
        ],
      ),
    );
  }
}
