import 'package:flutter/material.dart';

class DiscoveryScreen extends StatefulWidget {
  @override
  _DiscoveryScreenState createState() => _DiscoveryScreenState();
}

class _DiscoveryScreenState extends State<DiscoveryScreen> {
  double ageRangeValue = 25;
  double distanceValue = 50;
  bool expandSearch = false;
  bool hideLastSeen = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.red, // Red app bar background color
        title: Text('Discovery Settings'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            DiscoveryOption('Location', 'New York', () {
              // Handle Location option
              // You can use Navigator.push here
            }),
            SizedBox(height: 20),
            Text('Age Range', style: TextStyle(fontWeight: FontWeight.bold)),
            Slider(
              value: ageRangeValue,
              onChanged: (value) {
                setState(() {
                  ageRangeValue = value;
                });
              },
              min: 0,
              max: 100,
              activeColor: Colors.red,
              inactiveColor: Colors.redAccent.shade700,
            ),
            Text('Distance', style: TextStyle(fontWeight: FontWeight.bold)),
            Slider(
              value: distanceValue,
              onChanged: (value) {
                setState(() {
                  distanceValue = value;
                });
              },
              min: 0,
              max: 100,
              activeColor: Colors.red,
              inactiveColor: Colors.redAccent,
            ),
            DiscoveryOption('Expand Search Area', '', () {
              setState(() {
                expandSearch = !expandSearch;
              });
            }, hasToggleButton: true, isToggleOn: expandSearch),
            DiscoveryOption('Show Me', 'Women Only', () {
              // Handle Show Me option
              // You can use Navigator.push here
            }),
            DiscoveryOption('Hide Last Seen', '', () {
              setState(() {
                hideLastSeen = !hideLastSeen;
              });
            }, hasToggleButton: true, isToggleOn: hideLastSeen),
          ],
        ),
      ),
    );
  }
}

class DiscoveryOption extends StatelessWidget {
  final String title;
  final String subTitle;
  final VoidCallback onTap;
  final bool hasToggleButton;
  final bool isToggleOn;

  DiscoveryOption(this.title, this.subTitle, this.onTap,
      {this.hasToggleButton = false, this.isToggleOn = false});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        ListTile(
          onTap: onTap,
          title: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(title),
              if (subTitle.isNotEmpty) Text(subTitle),
              if (hasToggleButton) Icon(isToggleOn ? Icons.toggle_on : Icons.toggle_off, color: Colors.red),
            ],
          ),
          trailing: subTitle.isEmpty && !hasToggleButton ? Icon(Icons.arrow_forward_ios) : null,
        ),
        Divider(),
      ],
    );
  }
}
