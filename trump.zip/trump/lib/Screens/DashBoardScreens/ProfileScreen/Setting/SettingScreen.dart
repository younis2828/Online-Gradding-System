import 'package:flutter/material.dart';

import 'Discovery.dart';
import 'Language.dart';
import 'NotifyScreen.dart';
import 'Security.dart';

class SettingScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.red, // Red app bar background color
        title: Text('Settings'),
      ),
      body: Column(
        children: [
          SettingOption(
            icon: Icons.notifications,
            title: 'Notification',
            onPressed: ()
            {
             Navigator.push(context, MaterialPageRoute(builder: (context)=>NotificationScreen()));
            },
          ),
          SettingOption(
            icon: Icons.security,
            title: 'Security',
            onPressed: () {
              Navigator.push(context, MaterialPageRoute(builder: (context)=> SecurityScreen()));
            },
          ),
          SettingOption(
            icon: Icons.explore,
            title: 'Discovery',
            onPressed: () {
              Navigator.push(context, MaterialPageRoute(builder: (context)=> DiscoveryScreen()));
            },
          ),
          SettingOption(
            icon: Icons.language,
            title: 'Language',
            onPressed: () {
              Navigator.push(context, MaterialPageRoute(builder: (context)=> LanguageScreen()));
            },
          ),
          SettingOption(
            icon: Icons.info,
            title: 'About Trump Dating',
            onPressed: () {
              // Navigate to the respective screen for About
              // You can use Navigator.push here
            },
          ),
        ],
      ),
    );
  }
}

class SettingOption extends StatelessWidget {
  final IconData icon;
  final String title;
  final VoidCallback onPressed;

  SettingOption({required this.icon, required this.title, required this.onPressed});

  @override
  Widget build(BuildContext context) {
    return ListTile(
      onTap: onPressed,
      leading: Icon(icon),
      title: Text(title),
      trailing: Icon(Icons.arrow_forward_ios),
    );
  }
}
