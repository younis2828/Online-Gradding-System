import 'package:flutter/material.dart';
import 'GetVIP.dart';
import 'Setting/SettingScreen.dart';

class ProfileScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              SizedBox(height: 10,),
              CircleAvatar(
                radius: 60,
                backgroundImage: AssetImage('assets/images/homeimage.png'),
              ),
              SizedBox(height: 10),
              Text(
                'Charlotte Mathis',
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 18,
                ),
              ),
              Container(
                margin: EdgeInsets.all(20),
                padding: EdgeInsets.all(15),
                decoration: BoxDecoration(
                  color: Colors.red,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Center(
                      child: Text(
                        'Enjoy All Benefits!',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 16,
                          color: Colors.white
                        ),
                      ),
                    ),
                    SizedBox(height: 10),
                    Text(
                      'Enjoy unlimited swiping, like without restriction & without ads',
                      textAlign: TextAlign.center,
                    ),
                    Row(
                      children: [
                        ElevatedButton(
                          onPressed: ()
                          {
                            Navigator.push(context, MaterialPageRoute(builder: (context)=>GetVIP()));
                          },
                          child: Container(
                              width: 80,
                              height: 30,
                              child: Center(
                                  child: Text('Get Vip',style: TextStyle(color: Colors.red),
                                  )
                              )
                          ),
                        ),
                        SizedBox(height: 20),
                        Padding(
                          padding: const EdgeInsets.only(left: 120),
                          child: Image.asset(
                            "assets/icons/king.png",
                          ),
                        ),
                      ],
                    ),

                  ],
                ),
              ),

              SizedBox(height: 10),
              Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  TextButton(onPressed: ()
                      {
                        Navigator.push(context, MaterialPageRoute(builder: (context)=>SettingScreen()));
                      }
                      , child: Padding(
                        padding: const EdgeInsets.only(left: 40),
                        child: Row(
                          children: [
                            Icon(Icons.settings),
                            SizedBox(width: 10,),
                            Text('Settings',style: TextStyle(fontSize: 20,color: Colors.black87),),
                          ],
                        ),
                      )),
                  TextButton(onPressed: ()
                  {
                    Navigator.push(context, MaterialPageRoute(builder: (context)=>HelpCenterScreen()));
                  }
                      , child: Padding(
                        padding: const EdgeInsets.only(left: 40),
                        child: Row(
                          children: [
                            Icon(Icons.help),
                            SizedBox(width: 10,),
                            Text('Help Center',style: TextStyle(fontSize: 20,color: Colors.black87),),
                          ],
                        ),
                      )),
                  TextButton(onPressed: ()
                  {
                    Navigator.push(context, MaterialPageRoute(builder: (context)=>InviteFriendScreen()));
                  }
                      , child: Padding(
                        padding: const EdgeInsets.only(left: 40),
                        child: Row(
                          children: [
                            Icon(Icons.person_add),
                            SizedBox(width: 10,),
                            Text('Invite friend',style: TextStyle(fontSize: 20,color: Colors.black87),),
                          ],
                        ),
                      )),
                  TextButton(onPressed: ()
                  {
                    Navigator.push(context, MaterialPageRoute(builder: (context)=>LogoutScreen()));
                  }
                      , child: Padding(
                        padding: const EdgeInsets.only(left: 40),
                        child: Row(
                          children: [
                            Icon(Icons.logout),
                            SizedBox(width: 10,),
                            Text('Logout',style: TextStyle(fontSize: 20,color: Colors.black87),),
                          ],
                        ),
                      )),
                ],
              ),
              // buildTextButtonWithIcon(context, 'Settings', Icons.settings, SettingsScreen()),
              // buildTextButtonWithIcon(context, 'Help Center', Icons.help, HelpCenterScreen()),
              // buildTextButtonWithIcon(context, 'Invite friend', Icons.person_add, InviteFriendScreen()),
              // buildTextButtonWithIcon(context, 'Logout', Icons.logout, LogoutScreen()),
            ],
          ),
        ),
      ),
    );
  }

  // Widget buildTextButtonWithIcon(BuildContext context, String text, IconData icon, Widget screen) {
  //   return TextButton.icon(
  //     onPressed: () {
  //       Navigator.push(
  //         context,
  //         MaterialPageRoute(builder: (context) => screen),
  //       );
  //     },
  //     icon: Icon(icon),
  //     label: Text(text),
  //   );
  // }

  Widget buildTextButton(BuildContext context, String text, Color color) {
    return TextButton(
      onPressed: () {
        // Implement the action for the text button
      },
      style: TextButton.styleFrom(primary: color),
      child: Text(text),
    );
  }
}

class HelpCenterScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Help Center'),
      ),
      body: Center(
        child: Text('This is Help Center'),
      ),
    );
  }
}

class InviteFriendScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Invite Friend'),
      ),
      body: Center(
        child: Text('This is Invite friend'),
      ),
    );
  }
}

class LogoutScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Logout'),
      ),
      body: Center(
        child: Text('This is Logout'),
      ),
    );
  }
}
