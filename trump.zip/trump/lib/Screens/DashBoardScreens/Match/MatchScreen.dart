import 'package:flutter/material.dart';

class MatchScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.grey),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Row(
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Icon(Icons.search),
                    ),
                    Expanded(
                      child: TextField(
                        decoration: InputDecoration(
                          border: InputBorder.none,
                          hintText: 'Search',
                        ),
                      ),
                    ),
                    IconButton(
                      onPressed: ()
                      {
                        _showFilterBottomSheet(context);
                      },
                      icon: Icon(Icons.filter_list),
                    ),
                  ],
                ),
              ),
              SizedBox(height: 20),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Recent Matches',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  TextButton(
                    onPressed: () {
                      // Handle "See All" button press
                    },
                    child: Text('See All'),
                  ),
                ],
              ),
              SizedBox(height: 10),
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  children: List.generate(5, (index) {
                    return Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Column(
                        children: [
                          Image.asset(
                            'assets/images/homeimage.png',
                            width: 100,
                            height: 100,
                          ),
                          SizedBox(height: 5),
                          Text('calfor'),
                        ],
                      ),
                    );
                  }),
                ),
              ),
              SizedBox(height: 10),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Recent Matches',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  TextButton(
                    onPressed: () {
                      // Handle "See All" button press
                    },
                    child: Text('See All'),
                  ),
                ],
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Row(
                  children: [
                    Container(
                        width: 175,
                        child: Image.asset("assets/images/homeimage.png",)
                    ),
                    SizedBox(width: 10,),
                    Container(
                        width: 175,
                        child: Image.asset("assets/images/homeimage.png")
                    ),
                    SizedBox(width: 2),

                    // _buildImageColumn('assets/images/homeimage.png', 'calfor'),
                    // SizedBox(width: 2),
                    // _buildImageColumn('assets/images/homeimage.png', 'calfor'),
                  ],
                ),
              ),
              SizedBox(height: 10),
              Row(
                children: [
                  Container(
                      width: 175,
                      child: Image.asset("assets/images/homeimage.png",)
                  ),
                  SizedBox(width: 10,),
                  Container(
                      width: 175,
                      child: Image.asset("assets/images/homeimage.png")
                  ),
                  // _buildImageColumn('assets/images/homeimage.png', 'calfor'),
                  // SizedBox(width: 10),
                  // _buildImageColumn('assets/images/homeimage.png', 'calfor'),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Column _buildImageColumn(String imagePath, String text) {
    return Column(
      children: [
        Image.asset(
          imagePath,
          width: 100,
          height: 100,
        ),
        SizedBox(height: 5),
        Text(text),
      ],
    );
  }
}


void _showFilterBottomSheet(BuildContext context) {
  showModalBottomSheet(
    context: context,
    builder: (BuildContext context) {
      return Container(
        padding: EdgeInsets.all(16.0),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Filter',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
                TextButton(
                  onPressed: () {
                    // Handle "Reset" button press
                  },
                  child: Text('Reset'),
                ),
              ],
            ),
            SizedBox(height: 10),
            Text('Age'),
            SizedBox(height: 10),
            RangeSlider(
              values: RangeValues(0, 100),
              onChanged: (RangeValues values) {
                // Handle range slider value change
              },
              min: 0,
              max: 100,
              divisions: 100,
              activeColor: Colors.red,
              inactiveColor: Colors.grey,
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: ()
              {
                // Handle "Continue" button press
              },
              child: Text('Continue'),
              style: ElevatedButton.styleFrom(
                primary: Colors.red,
                minimumSize: Size(400, 60),
              ),
            ),
          ],
        ),
      );
    },
  );
}

