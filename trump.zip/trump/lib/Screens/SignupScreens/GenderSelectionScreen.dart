import 'package:flutter/material.dart';

import 'Sexuality.dart';

class GenderSelectionScreen extends StatefulWidget {
  @override
  _GenderSelectionScreenState createState() => _GenderSelectionScreenState();
}

class _GenderSelectionScreenState extends State<GenderSelectionScreen> {
  String selectedGender = '';

  void _selectGender(String gender) {
    setState(() {
      selectedGender = gender;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.red,
        title: Text('Gender'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(height: 20,),
            Text(
              'Gender',
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 24,
              ),
            ),
            SizedBox(height: 10),
            GestureDetector(
              onTap: () {
                _showGenderDialog();
              },
              child: Container(
                padding: EdgeInsets.symmetric(vertical: 16, horizontal: 12),
                width: 400,
                height: 60,
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.grey),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  selectedGender.isEmpty ? 'Select Gender' : selectedGender,
                  style: TextStyle(fontSize: 16),
                ),
              ),
            ),
            Spacer(),
            ElevatedButton(
              onPressed: ()
              {
                Navigator.push(context, MaterialPageRoute(builder: (context)=>SexualityScreen()));
              },
              child: Text('Continue'),
              style: ElevatedButton.styleFrom(
                primary: Colors.red,
                minimumSize: Size(400, 60),
              ),
            ),
          ],
        ),
      ),
    );
  }


  void _showGenderDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Container(
              width: 300,
              child: Text('Select Gender')),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              GestureDetector(
                onTap: () {
                  _selectGender('Male');
                  Navigator.pop(context);
                },
                child: Text('Male'),
              ),
              GestureDetector(
                onTap: () {
                  _selectGender('Female');
                  Navigator.pop(context);
                },
                child: Text('Female'),
              ),
            ],
          ),
        );
      },
    );
  }
}
