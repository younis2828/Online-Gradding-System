import 'package:flutter/material.dart';
import '../LoginScreens/LoginScreen.dart';
import 'AccountDisable.dart';

class PoliticalAffiliationScreen extends StatefulWidget {
  @override
  _PoliticalAffiliationScreenState createState() => _PoliticalAffiliationScreenState();
}

class _PoliticalAffiliationScreenState extends State<PoliticalAffiliationScreen> {
  String? selectedAffiliation;

  void _showOptionsDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Container(
              width: 500,
              height: 60,
              child: Text('Select Affiliation')),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              GestureDetector(
                onTap: () {
                  Navigator.pop(context);
                  setState(() {
                    selectedAffiliation = 'Democrate';
                  });
                },
                child: Container(
                  padding: EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    border: Border.all(color: Colors.grey),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    'Democrate',
                    style: TextStyle(fontSize: 18),
                  ),
                ),
              ),
              SizedBox(height: 10),
              GestureDetector(
                onTap: () {
                  Navigator.pop(context);
                  setState(() {
                    selectedAffiliation = 'Republican';
                  });
                },
                child: Container(
                  padding: EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    border: Border.all(color: Colors.grey),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    'Republican',
                    style: TextStyle(fontSize: 18),
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.red,
        title: Text('Political Affiliation'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            GestureDetector(
              onTap: () {
                _showOptionsDialog();
              },
              child: Container(
                padding: EdgeInsets.all(12),
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.grey),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  selectedAffiliation ?? 'Select Affiliation',
                  style: TextStyle(fontSize: 18),
                ),
              ),
            ),
            SizedBox(height: 400),
            ElevatedButton(
              onPressed: () {
                if (selectedAffiliation == 'Democrate') {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => AccountDisable()), // Navigate to AccountDisable
                  );
                } else if (selectedAffiliation == 'Republican') {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => LoginScreen()), // Navigate to LoginScreen
                  );
                }
              },
              child: Container(
                width: 350,
                  height: 60,
                  child: Center(child: Text('Continue'))),
              style: ElevatedButton.styleFrom(
                primary: Colors.red,
                minimumSize: Size(200, 60),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
