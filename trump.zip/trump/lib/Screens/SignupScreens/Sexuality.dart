import 'package:flutter/material.dart';

import 'Political.dart';// Make sure you have the correct import

class SexualityScreen extends StatefulWidget {
  @override
  _SexualityScreenState createState() => _SexualityScreenState();
}

class _SexualityScreenState extends State<SexualityScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.red,
        title: Text('Sexuality'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            SizedBox(height: 30),
            Container(
              width: 315,
              height: 60,
              padding: EdgeInsets.all(12),
              decoration: BoxDecoration(
                border: Border.all(color: Colors.grey),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Center(
                child: Text(
                  'Straight',
                  style: TextStyle(fontSize: 20),
                ),
              ),
            ),
            SizedBox(height: 400),
            Container(
              width: 400,
              child: ElevatedButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => PoliticalAffiliationScreen()),
                  );
                },
                child: Text('Continue'),
                style: ElevatedButton.styleFrom(
                  primary: Colors.red,
                  minimumSize: Size(200, 60),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
