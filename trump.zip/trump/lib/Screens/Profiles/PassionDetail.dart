import 'package:flutter/material.dart';

import '../DashBoardScreens/Dashboard.dart';

class PassionDetailScreen extends StatefulWidget {
  @override
  _PassionDetailScreenState createState() => _PassionDetailScreenState();
}

class _PassionDetailScreenState extends State<PassionDetailScreen> {
  List<String> passions = [
    'DIY',
    'Hugx Hug',
    'Politics',
    'Cycling',
    'Museum',
    'Outdoors',
    'Shopping',
    'Picnicking',
    'Comedy',
    'Brunch',
    'Music',
    'Netflix',
    'Tea X',
    'Disney',
    'Dog Lover',
    'Craft Beer',
    'Swimming',
    'Board Games X',
    'via Trivia',
    'Volunteering',
    'Hiking',
    'Environmentalism X',
    'Wine',
    'Vlogging',
    'Yoga X',
    'Cat Lover',
    'Working Out',
    'Fishing',
  ];

  List<bool> selectedPassions = [];

  @override
  void initState() {
    super.initState();
    selectedPassions = List.generate(passions.length, (index) => false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.red,
        title: Text('Passion Detail'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Select Your Passions',
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 18,
              ),
            ),
            SizedBox(height: 20),
            Wrap(
              spacing: 8.0,
              runSpacing: 8.0,
              children: List.generate(passions.length, (index) {
                return GestureDetector(
                  onTap: () {
                    setState(() {
                      selectedPassions[index] = !selectedPassions[index];
                    });
                  },
                  child: Container(
                    padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(
                        color: selectedPassions[index] ? Colors.red : Colors.grey,
                      ),
                    ),
                    child: Text(
                      passions[index],
                      style: TextStyle(
                        color: selectedPassions[index] ? Colors.red : Colors.black,
                      ),
                    ),
                  ),
                );
              }),
            ),
            Spacer(),
            ElevatedButton(
              onPressed: ()
              {
                Navigator.push(context, MaterialPageRoute(builder: (context)=>DashboardScreen()));
              },
              child: Text('Continue'),
              style: ElevatedButton.styleFrom(
                primary: Colors.red,
                minimumSize: Size(double.infinity, 60),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
