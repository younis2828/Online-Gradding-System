import 'package:flutter/material.dart';

import 'LoginOTP.dart';

class LoginScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.red,
        title: Text('Login Screen'),
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            SizedBox(height: 20,),
            Text(
              'Email Address',
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 18,
              ),
            ),
            SizedBox(height: 10),
            TextField(
              decoration: InputDecoration(
                border: OutlineInputBorder(),
                hintText: 'Enter Your Email',
              ),
              style: TextStyle(fontSize: 16),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: ()
              {
                Navigator.push(context, MaterialPageRoute(builder: (context)=>OTPLoginScreen()));
              },
              child: Text('Continue'),
              style: ElevatedButton.styleFrom(
                primary: Colors.red,
                minimumSize: Size(300, 60),
              ),
            ),
            SizedBox(height: 30),
            Center(
              child: Container(
                height: 1,
                width: double.infinity,
                color: Colors.grey,
                child: Center(
                  child: Padding(
                    padding: EdgeInsets.symmetric(horizontal: 10),
                    child: Text('or'),
                  ),
                ),
              ),
            ),
            SizedBox(height: 30),
            _buildSocialButton('Continue with iPhone', Icons.phone),
            SizedBox(height: 10),
            _buildSocialButton('Continue with Apple', Icons.account_circle),
            SizedBox(height: 10),
            _buildSocialButton('Continue with Gmail', Icons.mail),
            SizedBox(height: 10),
            _buildSocialButton('Continue with Email', Icons.email),
            SizedBox(height: 20), // Add some space at the bottom
          ],
        ),
      ),
    );
  }

  Widget _buildSocialButton(String text, IconData icon) {
    return OutlinedButton.icon(
      onPressed: () {
        // Perform the action when a social button is pressed
      },
      icon: Icon(icon),
      label: Text(text),
      style: OutlinedButton.styleFrom(
        minimumSize: Size(300, 60),
        side: BorderSide(color: Colors.grey),
      ),
    );
  }
}
