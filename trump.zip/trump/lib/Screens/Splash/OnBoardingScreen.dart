import 'package:flutter/material.dart';

import '../SignupScreens/CreateAccount.dart';


class OnboardingScreen extends StatefulWidget {
  @override
  _OnboardingScreenState createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  final PageController _pageController = PageController();
  int _currentPage = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          Expanded(
            flex: 3,
            child: Center(
              child: PageView(
                controller: _pageController,
                onPageChanged: (int page) {
                  setState(() {
                    _currentPage = page;
                  });
                },
                children: [
                  OnboardingSlide(
                    image: 'assets/images/board1.png',
                    heading: 'Meaningful Connections',
                    text: 'Find like minded individuals that share your conservative values',
                  ),
                  OnboardingSlide(
                    image: 'assets/images/board2.png',
                    heading: 'Local Conservatives',
                    text: 'Connect with fellow conservatives in your area',
                  ),
                  OnboardingSlide(
                    image: 'assets/images/board3.png',
                    heading: 'Meaningful Conversations',
                    text: 'Get to know your match through our personalized messaging system',
                  ),
                ],
              ),
            ),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: List.generate(3, (index) => buildBullet(index)),
          ),
          SizedBox(height: 20),
          ElevatedButton(
            onPressed: () {
              if (_currentPage < 2) {
                _pageController.nextPage(
                  duration: Duration(milliseconds: 300),
                  curve: Curves.easeInOut,
                );
              } else
              {
                Navigator.push(context, MaterialPageRoute(builder: (builder)=>CreateAccountScreen()));
              }
            },
            child: Text('Next'),
            style: ElevatedButton.styleFrom(
              minimumSize: Size(300, 50),
              primary: Colors.red,
            ),
          ),
          SizedBox(height: 10),
          TextButton(
            onPressed: ()
            {

            },
            child: Text('Skip'),
            style: TextButton.styleFrom(
              minimumSize: Size(300, 50),
              shape: RoundedRectangleBorder(
                side: BorderSide(color: Colors.black),
                borderRadius: BorderRadius.circular(8.0),
              ),
            ),
          ),
          SizedBox(height: 20),
        ],
      ),
    );
  }

  Widget buildBullet(int index) {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 4),
      width: 10,
      height: 10,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: _currentPage == index ? Colors.blue : Colors.grey,
      ),
    );
  }
}

class OnboardingSlide extends StatelessWidget {
  final String image;
  final String heading;
  final String text;

  OnboardingSlide({
    required this.image,
    required this.heading,
    required this.text,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Image.asset(image),
        SizedBox(height: 20),
        Text(
          heading,
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 24,
          ),
        ),
        SizedBox(height: 10),
        Text(
          text,
          style: TextStyle(
            fontSize: 16,
          ),
        ),
      ],
    );
  }
}